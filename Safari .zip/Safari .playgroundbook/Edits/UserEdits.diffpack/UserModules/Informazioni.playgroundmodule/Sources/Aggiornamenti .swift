// Aggioenamento 17/03/22 aggiunta della cronologia (anche dopo chiusura dell'app) e ultime patch bug
