// codice sorgente utilizzato da Berry_13
